namespace DotNetGalutinis.Server.Models.Inventory;

public class ReservationInfo
{
    public string UserInfo { get; set; }
    public string ItemInfo { get; set; }
}